# YouTube Downloader Portable 
 
EN: Portable version of YouTube Downloader 
 
Files: 
- yt-downloader.exe - main application 
- bin\yt-dlp.exe - downloading utility 
- assets\beep_long.wav - completion sound 
- links.txt - batch download list 
 
Usage: 
1. Run yt-downloader.exe 
2. For batch downloads, add URLs to links.txt 
 
ES: Version portable del descargador de YouTube 
Archivos: 
- yt-downloader.exe - aplicacion principal 
- bin\yt-dlp.exe - utilidad de descarga 
- assets\beep_long.wav - sonido de finalizacion 
- links.txt - lista para descargas por lotes 
Uso: 
1. Ejecute yt-downloader.exe 
2. Para descargas por lotes, agregue URL en links.txt 
