# YouTube Downloader Portable 
 
Portable версия YouTube Downloader 
 
Файлы: 
- yt-downloader.exe - основная программа 
- bin\yt-dlp.exe - утилита для скачивания 
- assets\beep_long.wav - звуковой сигнал 
- links.txt - файл для пакетной загрузки 
 
Использование: 
1. Запустите yt-downloader.exe 
2. Для пакетной загрузки добавьте URL в links.txt 
